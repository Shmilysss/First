# JavaWeb-SSHTemplate
使用Maven管理的SSH项目模板，适合jdk8，tomcat8.5，IntelliJ idea。
帮助你快速开始一个标准的JavaWeb项目

使用说明：https://zhuanlan.zhihu.com/p/25665671y
微信公众号：GeeYao
有问题请联系我
